<?php
include('functions.php');
clear_slate();
 ?>
