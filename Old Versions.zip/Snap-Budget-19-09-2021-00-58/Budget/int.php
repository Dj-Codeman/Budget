<?php
include("server.php");
include("functions.php");

echo "$uid\n";
//$a = "debit";
//fetch_account($a);
//echo "$acnt_num\n";
//clear_slate();
//check_bills();


//$select = "SELECT * FROM Budget.Income";
//$result = mysqli_query($db, $select);

//while($row = mysqli_fetch_assoc($result)) {

//$user = "602d5b998a635";
//$Outcome_id = $row['uid'];

//$update = "UPDATE Budget.Income SET Income_owner = '$user' WHERE uid = '$Outcome_id' ";
//echo "$update";
//mysqli_query($db, $update);
//}

?>
