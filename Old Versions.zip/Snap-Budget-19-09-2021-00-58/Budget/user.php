<?php
$embeded = "1";
$username = "Darrionw";
$password = "Dardar7816!";
$_POST['login'] = "set";

include('server.php');


?>
